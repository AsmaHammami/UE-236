/** Automatically generated file. DO NOT MODIFY */
package com.deust.applicontact;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}